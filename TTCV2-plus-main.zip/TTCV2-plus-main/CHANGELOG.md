**TTCV2 - CHANGELOG**

**2024.1.5** - Extension launched, bringing our most loved paints back in game, matte paints.

**2024.1.12** - Some old tank parts have been found, what could I do with them? Hehe, why not, old tanks are back! With a little rework, in order to keep them functional. And for even better mayhem in mazes, Classic Mazes spice it up.

**2024.1.21** - Found in the lost folder in the underground laboratory. Dusty, seems like they haven't been used in years. No more waiting, time to shine once again, Classic Tabs are back.

**2024.7.3** - Classic TankTrouble UI make a return into BETA! Already sounds interesting? Go! Install the extension and see how does Tank Trouble look like now. Warning! You will be amazed.

In TTCV2, we don't just bring back colors; we unravel the artistry of TankTrouble's heritage. Get ready for a scientific odyssey into the heart of nostalgic gaming graphics.

**2024.4.11** - Alot of CLassic UI upgrades! Website Statistics, Updated tank sprites, Classic Mouse, More games, and more!...

**2024.4.18** - Classic UI improvements, Chat remake, Bug fixes...

**2024.4.30** - More UI improvements, More matte versions of paints (Warfare Paints), Bug fixes.
